package com.surya.controller;

import java.util.List;

import com.surya.dto.BikeModel;

public class BikeControllerImpl implements IBikeController {

	public List<BikeModel> getAllBikes() {
		// TODO Auto-generated method stub
		return null;
	}

	public BikeModel addBikes(int id, BikeModel bike) {
		// TODO Auto-generated method stub
		return null;
	}

	public BikeModel updateBike(int id, BikeModel bike) {
		// TODO Auto-generated method stub
		return null;
	}

	public BikeModel deleteBikeById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public BikeModel getBikeById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<BikeModel> getRenterById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

}
