package com.surya.service;

import java.time.LocalDate;

import com.surya.dto.RenterModel;

public class RentalServiceImpl implements IRentalService {

	public double getRenterEarning(int renterId) {
		// TODO Auto-generated method stub
		return 0;
	}

	public RenterModel getRenterById(int renterId) {
		// TODO Auto-generated method stub
		return null;
	}

	public RenterModel updateProfile(int id, RenterModel renter) {
		// TODO Auto-generated method stub
		return null;
	}

	public double calculateRevenue(int id, LocalDate startDate, LocalDate endDate) {
		// TODO Auto-generated method stub
		return 0;
	}

}
