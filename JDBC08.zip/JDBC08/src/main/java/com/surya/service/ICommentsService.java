package com.surya.service;

import com.surya.dto.CommentsModel;

public interface ICommentsService {
	
	public CommentsModel addComments(CommentsModel comments);

}
