package com.surya.service;

import com.surya.dto.CommentsModel;

public class CommentServiceImpl implements ICommentsService {

	public CommentsModel addComments(CommentsModel comments) {
		// TODO Auto-generated method stub
		return null;
	}

}
