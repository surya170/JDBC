package com.surya.service;

import java.util.List;

import com.surya.dto.BookingModel;

public class BookingServiceImpl implements IBookingService {

	public BookingModel saveBookingHistory(int id, BookingModel data) {
		// TODO Auto-generated method stub
		return null;
	}

	public void updateEarnings(int id, double amount) {
		// TODO Auto-generated method stub

	}

	public BookingModel getAllBokkings() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<BookingModel> getCustomerBooking(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<BookingModel> getRenterBookingModels(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public BookingModel deleteBookingById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
