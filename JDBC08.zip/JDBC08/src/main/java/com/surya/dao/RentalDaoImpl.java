package com.surya.dao;

import java.util.List;

import com.surya.dto.BikeModel;
import com.surya.dto.CustomerModel;
import com.surya.dto.PaymentModel;
import com.surya.dto.RenterModel;

public class RentalDaoImpl implements IRentalDao {

	public List<BikeModel> getCustomerBike() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<BikeModel> getActiveBikes(List<RenterModel> renters, List<BikeModel> bikes) {
		// TODO Auto-generated method stub
		return null;
	}

	public CustomerModel delete(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public CustomerModel update(int id, CustomerModel customer) {
		// TODO Auto-generated method stub
		return null;
	}

	public CustomerModel getCustomerById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public PaymentModel validatePayment(PaymentModel payment) {
		// TODO Auto-generated method stub
		return null;
	}

}
