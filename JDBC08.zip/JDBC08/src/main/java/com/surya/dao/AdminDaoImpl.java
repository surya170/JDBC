package com.surya.dao;

import java.time.LocalDate;
import java.util.List;

import com.surya.dto.BikeModel;
import com.surya.dto.CommentsModel;
import com.surya.dto.CustomerModel;
import com.surya.dto.RenterModel;

public class AdminDaoImpl implements IAdminDao {

	public List<CustomerModel> getAllCustomers() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<RenterModel> getAllRenters() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<BikeModel> getRenterById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	public RenterModel isRenterActive(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	public CustomerModel isCustomerActive(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<CommentsModel> getAllComments() {
		// TODO Auto-generated method stub
		return null;
	}

	public Double calculateRevenue(LocalDate startDate, LocalDate endDate) {
		// TODO Auto-generated method stub
		return null;
	}

}
